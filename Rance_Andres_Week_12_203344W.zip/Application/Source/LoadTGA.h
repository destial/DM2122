#ifndef LOAD_TGA_H
#define LOAD_TGA_H
#include <GL\glew.h>
#include <GLFW\glfw3.h>

GLuint LoadTGA(const char *file_path);
GLFWcursor* LoadCrosshair(const char* file_path);
#endif